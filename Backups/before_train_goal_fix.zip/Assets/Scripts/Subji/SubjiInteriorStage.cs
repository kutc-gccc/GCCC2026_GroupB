using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections.Generic;

/// <summary>屋内シーンで編集する入場地点と移動範囲。</summary>
public sealed class SubjiInteriorStage : MonoBehaviour
{
    public Transform startPoint;
    public SubjiMovementArea2D movementArea;
    public Tilemap walkableTilemap;
    public TileBase walkableTile;
    public Sprite previewPlayerSprite;
    private Tile boundaryTile;
    [Header("潜入調査の周回地点（空欄なら床から自動設定）")]
    public Transform[] tourCheckpoints;
    [Min(0.1f)] public float tourArrivalRadius = 1.5f;
    public bool TourCompleted { get; private set; }
    private SubjiPlayerMovement tourPlayer;
    private readonly List<Vector3> tourPoints = new();
    private int nextTourPoint;
    private GUIStyle tourStyle;
    private Sprite dollPartSprite;

    public void BeginTour(SubjiPlayerMovement visitor)
    {
        tourPlayer = visitor;
        nextTourPoint = 0;
        TourCompleted = false;
        tourPoints.Clear();
        if (tourCheckpoints != null)
            foreach (var point in tourCheckpoints)
                if (point != null) tourPoints.Add(point.position);
        if (tourPoints.Count == 0 && walkableTilemap != null && walkableTile != null && startPoint != null)
        {
            // 到達可能な床のみを一度探索し、入口から最も遠い床までの経路を案内する。
            Vector3Int start = walkableTilemap.WorldToCell(startPoint.position);
            Vector3Int nearest = start;
            float distance = float.PositiveInfinity;
            foreach (var cell in walkableTilemap.cellBounds.allPositionsWithin)
                if (walkableTilemap.GetTile(cell) == walkableTile && (cell - start).sqrMagnitude < distance)
                { nearest = cell; distance = (cell - start).sqrMagnitude; }
            var parents = new Dictionary<Vector3Int, Vector3Int> { [nearest] = nearest };
            var queue = new Queue<Vector3Int>();
            queue.Enqueue(nearest);
            Vector3Int last = nearest;
            Vector3Int[] directions = { Vector3Int.up, Vector3Int.down, Vector3Int.left, Vector3Int.right };
            while (queue.Count > 0)
            {
                last = queue.Dequeue();
                foreach (var direction in directions)
                {
                    var next = last + direction;
                    if (parents.ContainsKey(next) || walkableTilemap.GetTile(next) != walkableTile) continue;
                    parents[next] = last;
                    queue.Enqueue(next);
                }
            }
            var path = new List<Vector3Int>();
            while (last != nearest) { path.Add(last); last = parents[last]; }
            path.Reverse();
            if (path.Count > 2)
            {
                tourPoints.Add(walkableTilemap.GetCellCenterWorld(path[path.Count / 3]));
                tourPoints.Add(walkableTilemap.GetCellCenterWorld(path[path.Count * 2 / 3]));
                tourPoints.Add(walkableTilemap.GetCellCenterWorld(path[path.Count - 1]));
            }
        }
        if (tourPoints.Count == 0) Debug.LogWarning("潜入調査の周回地点を設定してください", this);
        else CreateBrokenDoll(tourPoints[tourPoints.Count - 1]);
    }

    private void CreateBrokenDoll(Vector3 position)
    {
        if (transform.Find("Broken Doll (placeholder)") != null) return;
        var doll = new GameObject("Broken Doll (placeholder)");
        doll.transform.SetParent(transform, false);
        doll.transform.position = position;
        dollPartSprite = Sprite.Create(Texture2D.whiteTexture, new Rect(0, 0, 1, 1), Vector2.one * 0.5f, 1f);
        AddDollPart(doll.transform, "Head", new Vector2(0f, 0.3f), new Vector2(0.35f, 0.35f), new Color(0.8f, 0.7f, 0.6f));
        AddDollPart(doll.transform, "Body", Vector2.zero, new Vector2(0.3f, 0.4f), new Color(0.5f, 0.15f, 0.2f));
        AddDollPart(doll.transform, "Leg", new Vector2(-0.1f, -0.3f), new Vector2(0.12f, 0.25f), Color.gray);
        AddDollPart(doll.transform, "Detached Arm", new Vector2(0.45f, -0.15f), new Vector2(0.25f, 0.1f), new Color(0.8f, 0.7f, 0.6f));
    }

    private void AddDollPart(Transform parent, string name, Vector2 offset, Vector2 size, Color color)
    {
        var part = new GameObject(name);
        part.transform.SetParent(parent, false);
        part.transform.localPosition = offset;
        part.transform.localScale = new Vector3(size.x, size.y, 1f);
        var renderer = part.AddComponent<SpriteRenderer>();
        renderer.sprite = dollPartSprite;
        renderer.color = color;
        renderer.sortingOrder = 100;
    }

    private void Update()
    {
        if (tourPlayer == null || TourCompleted || tourPoints.Count == 0 || Time.timeScale <= 0f) return;
        if (Vector2.Distance(tourPlayer.transform.position, tourPoints[nextTourPoint]) > tourArrivalRadius) return;
        nextTourPoint++;
        TourCompleted = nextTourPoint == tourPoints.Count;
    }

    private void OnGUI()
    {
        if (tourPlayer == null || tourPoints.Count == 0) return;
        tourStyle ??= new GUIStyle(GUI.skin.box) { fontSize = 22, alignment = TextAnchor.MiddleCenter };
        string message = TourCompleted ? "調査完了：出口へ戻ろう" :
            $"潜入調査 {nextTourPoint}/{tourPoints.Count}　案内地点へ進もう";
        GUI.Box(new Rect((Screen.width - 520f) / 2f, 24f, 520f, 44f), message, tourStyle);
        if (!TourCompleted && Camera.main != null)
        {
            Vector3 point = Camera.main.WorldToScreenPoint(tourPoints[nextTourPoint]);
            if (point.z > 0f)
                GUI.Box(new Rect(Mathf.Clamp(point.x - 70f, 0f, Screen.width - 140f),
                    Mathf.Clamp(Screen.height - point.y - 22f, 80f, Screen.height - 44f), 140f, 44f), "調査地点", tourStyle);
        }
    }


    public Vector4 GetBlockingWallRect(Vector2 hitPoint, Vector2 direction)
    {
        Vector3Int cell = walkableTilemap.WorldToCell(hitPoint + direction * 0.03f);
        TileBase tile = walkableTilemap.GetTile(cell);
        if (tile == null || tile == walkableTile)
            return new Vector4(1f, 1f, -1f, -1f);
        // 上下に接する壁タイルも同じ壁面として表示する（床の奥は広げない）。
        Vector3Int bottom = cell;
        Vector3Int top = cell + new Vector3Int(1, 1, 0);
        TileBase above = walkableTilemap.GetTile(cell + Vector3Int.up);
        TileBase below = walkableTilemap.GetTile(cell + Vector3Int.down);
        if (above != null && above != walkableTile)
            top += Vector3Int.up;
        if (below != null && below != walkableTile)
            bottom += Vector3Int.down;
        Vector3 a = walkableTilemap.CellToWorld(bottom);
        Vector3 b = walkableTilemap.CellToWorld(top);
        return new Vector4(Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y),
            Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y));
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (previewPlayerSprite != null)
            return;
        foreach (Object asset in UnityEditor.AssetDatabase.LoadAllAssetsAtPath(
            "Assets/Sprites/Player/Sprite-0001.aseprite"))
            if (asset is Sprite sprite)
            {
                previewPlayerSprite = sprite;
                break;
            }
    }
#endif

    private void Awake()
    {
        if (walkableTilemap == null || walkableTile == null)
            return;
        GameObject boundary = new("Wood Floor Boundary");
        boundary.transform.SetParent(walkableTilemap.transform, false);
        Tilemap boundaryMap = boundary.AddComponent<Tilemap>();
        boundaryTile = ScriptableObject.CreateInstance<Tile>();
        boundaryTile.colliderType = Tile.ColliderType.Grid;
        foreach (Vector3Int cell in walkableTilemap.cellBounds.allPositionsWithin)
            if (walkableTilemap.GetTile(cell) == walkableTile)
                boundaryMap.SetTile(cell, boundaryTile);
        Rigidbody2D body = boundary.AddComponent<Rigidbody2D>();
        body.bodyType = RigidbodyType2D.Static;
        CompositeCollider2D outline = boundary.AddComponent<CompositeCollider2D>();
        outline.geometryType = CompositeCollider2D.GeometryType.Outlines;
        TilemapCollider2D tiles = boundary.AddComponent<TilemapCollider2D>();
        tiles.compositeOperation = Collider2D.CompositeOperation.Merge;
        tiles.ProcessTilemapChanges();
        outline.GenerateGeometry();
    }

    private void Start()
    {
        // 通常の入場時は既存プレイヤーを使い、直接再生時だけ確認用を用意する。
        if (FindFirstObjectByType<SubjiPlayerMovement>() != null || startPoint == null)
            return;
        GameObject actor = new("Interior Preview Player");
        actor.SetActive(false);
        actor.transform.SetParent(transform, false);
        actor.transform.position = startPoint.position;
        actor.transform.localScale = Vector3.one * 1.5f;
        SpriteRenderer sprite = actor.AddComponent<SpriteRenderer>();
        sprite.sprite = previewPlayerSprite;
        sprite.sharedMaterial = walkableTilemap.GetComponent<TilemapRenderer>().sharedMaterial;
        sprite.sortingOrder = 100;
        actor.AddComponent<BoxCollider2D>().size = Vector2.one / 3f;
        Rigidbody2D body = actor.AddComponent<Rigidbody2D>();
        body.gravityScale = 0f;
        body.freezeRotation = true;

        GameObject view = new("Interior Preview Camera");
        view.transform.SetParent(transform, false);
        view.tag = "MainCamera";
        Camera camera = view.AddComponent<Camera>();
        camera.orthographic = true;
        camera.orthographicSize = 6f;
        camera.backgroundColor = Color.black;
        camera.clearFlags = CameraClearFlags.SolidColor;
        view.AddComponent<AudioListener>();
        SubjiCameraFollow follow = view.AddComponent<SubjiCameraFollow>();
        follow.player = actor.transform;
        follow.SnapToPlayer();
        SubjiPlayerMovement movement = actor.AddComponent<SubjiPlayerMovement>();
        movement.IsStandalonePreview = true;
        actor.SetActive(true);
    }

    private void OnDestroy()
    {
        if (dollPartSprite != null)
            Destroy(dollPartSprite);
        if (boundaryTile != null)
            Destroy(boundaryTile);
    }

    public bool CanStandAt(Vector2 position, Vector2 extents)
    {
        if (walkableTilemap == null || walkableTile == null)
            return false;
        extents = Vector2.Max(Vector2.zero, extents - Vector2.one * 0.001f);
        Vector3Int min = walkableTilemap.WorldToCell(position - extents);
        Vector3Int max = walkableTilemap.WorldToCell(position + extents);
        for (int y = min.y; y <= max.y; y++)
            for (int x = min.x; x <= max.x; x++)
                if (walkableTilemap.GetTile(new Vector3Int(x, y, min.z)) != walkableTile)
                    return false;
        return true;
    }

    public Vector2 ConstrainMovement(Vector2 current, Vector2 desired, Vector2 extents)
    {
        Vector2 origin = current;
        // 小さく分けて判定し、速度アップ中も床の隙間を飛び越えない。
        int steps = Mathf.Max(1, Mathf.CeilToInt(Vector2.Distance(current, desired) / 0.1f));
        Vector2 step = (desired - current) / steps;
        for (int i = 0; i < steps; i++)
        {
            Vector2 next = current + step;
            if (CanStandAt(next, extents))
                current = next;
            else
            {
                next = current + new Vector2(step.x, 0f);
                if (CanStandAt(next, extents))
                    current = next;
                next = current + new Vector2(0f, step.y);
                if (CanStandAt(next, extents))
                    current = next;
            }
        }
        return SubjiRoadMap.ConstrainToArea(origin, current, extents, movementArea);
    }

    private void OnDrawGizmos()
    {
        if (startPoint == null)
            return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(startPoint.position, 0.6f);
        Gizmos.DrawLine(startPoint.position, startPoint.position + Vector3.right * 2f);
    }
}
