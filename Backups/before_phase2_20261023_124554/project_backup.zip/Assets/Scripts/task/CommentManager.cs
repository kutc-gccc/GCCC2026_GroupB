using UnityEngine;
using TMPro;
using System;

public class CommentManager : MonoBehaviour
{
    // ==================================================
    // �ʏ�R�����g
    // ==================================================

    [Header("========== �ʏ�R�����g ==========")]

    [Header("�R�����gPrefab")]
    public GameObject commentPrefab;

    [Header("�R�����g������")]
    public RectTransform commentContent;

    [Header("�R�����g�����ʒu")]
    public RectTransform spawnPoint;

    [Header("�ʏ�̒P��")]
    public string[] words;


    // ==================================================
    // ����R�����g
    // ==================================================

    [Header("========== ����R�����g ==========")]

    [Header("����R�����gPrefab")]
    public GameObject specialWordPrefab;

    [Header("����R�����g������")]
    public RectTransform specialContent;

    [Header("����R�����g�����ʒu")]
    public RectTransform specialSpawnPoint;

    [Header("����P��")]
    public SpecialWordData[] specialWords;

    [Header("����P��̏o���m���i���j")]
    [Range(0f, 100f)]
    public float specialSpawnChance = 5f;

    [Header("����P��̐F")]
    public Color specialWordColor = Color.yellow;


    // ==================================================
    // ����R�����g�ۑ��ݒ�
    // ==================================================

    [Header("========== ����R�����g�ۑ� ==========")]

    [Header("����P��̍ő�ێ���")]
    public int maxSpecialWords = 3;


    // ==================================================
    // �ʏ�R�����g�ݒ�
    // ==================================================

    [Header("========== �ʏ�R�����g�ݒ� ==========")]

    [Header("�R�����g�����Ԋu")]
    public float spawnInterval = 1f;

    [Header("�ʏ�R�����g�ő�\����")]
    public int maxComments = 8;

    [Header("�ʏ�R�����g�̏c�Ԋu")]
    public float commentHeight = 60f;


    // ==================================================
    // ����R�����g�ݒ�
    // ==================================================

    [Header("========== ����R�����g�ݒ� ==========")]

    [Header("����R�����g�̏c�Ԋu")]
    public float specialCommentHeight = 60f;


    // ==================================================
    // ����P��t���O
    // ==================================================

    private bool[] specialFlags;


    // ==================================================
    // ����P��o���C�x���g
    // int = Element�ԍ�
    // ==================================================

    public event Action<int> OnSpecialWordAppeared;


    private float timer;


    // ==================================================
    // Start
    // ==================================================

    void Start()
    {
        if (specialWords != null)
        {
            specialFlags = new bool[specialWords.Length];

            for (int i = 0; i < specialFlags.Length; i++)
            {
                specialFlags[i] = false;
            }
        }
    }


    // ==================================================
    // Update
    // ==================================================

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            timer = 0f;

            AddComment();
        }
    }


    // ==================================================
    // �R�����g�ǉ�
    // ==================================================

    void AddComment()
    {
        if (commentPrefab == null)
        {
            Debug.LogWarning("Comment Prefab���ݒ肳��Ă��܂���B");
            return;
        }

        if (commentContent == null)
        {
            Debug.LogWarning("Comment Content���ݒ肳��Ă��܂���B");
            return;
        }

        if (spawnPoint == null)
        {
            Debug.LogWarning("Spawn Point���ݒ肳��Ă��܂���B");
            return;
        }

        if (words == null || words.Length == 0)
        {
            Debug.LogWarning("�ʏ�̒P�ꂪ�ݒ肳��Ă��܂���B");
            return;
        }


        // ==================================================
        // ����P����o���邩�m�F
        // ==================================================

        bool canSpawnSpecial =
            specialWords != null &&
            specialWords.Length > 0 &&
            specialContent != null &&
            specialSpawnPoint != null &&
            specialWordPrefab != null &&
            specialContent.childCount < maxSpecialWords;


        bool isSpecial = false;

        int specialIndex = -1;


        // ==================================================
        // ����P�ꒊ�I
        // ==================================================

        if (canSpawnSpecial)
        {
            float randomValue =
                UnityEngine.Random.Range(0f, 100f);

            if (randomValue < specialSpawnChance)
            {
                specialIndex =
                    GetRandomAvailableSpecialIndex();

                if (specialIndex >= 0)
                {
                    isSpecial = true;
                }
            }
        }


        // ==================================================
        // �o������������
        // ==================================================

        string selectedWord;

        if (isSpecial)
        {
            selectedWord =
                specialWords[specialIndex].appearanceWord;
        }
        else
        {
            selectedWord =
                words[
                    UnityEngine.Random.Range(
                        0,
                        words.Length
                    )
                ];
        }


        // ==================================================
        // �ʏ�R�����g�𐶐�
        // ==================================================

        GameObject newComment =
            Instantiate(
                commentPrefab,
                commentContent
            );


        TMP_Text text =
            newComment.GetComponent<TMP_Text>();


        if (text != null)
        {
            text.text = selectedWord;

            if (isSpecial)
            {
                text.color = specialWordColor;
            }
            else
            {
                text.color = Color.white;
            }
        }


        // ��ԏ�ɂ���

        newComment.transform.SetAsFirstSibling();


        // �ʏ�R�����g����ׂ�

        ArrangeComments();


        // �ő吔�𒴂������ԌÂ����̂��폜

        if (commentContent.childCount > maxComments)
        {
            Destroy(
                commentContent
                    .GetChild(
                        commentContent.childCount - 1
                    )
                    .gameObject
            );
        }


        // ==================================================
        // ����P�ꂾ�����ꍇ
        // ==================================================

        if (isSpecial)
        {
            HandleSpecialWord(specialIndex);
        }
    }


    // ==================================================
    // ����P�ꏈ��
    // ==================================================

    void HandleSpecialWord(int index)
    {
        if (index < 0)
            return;

        // Element�ԍ��̃t���O��ON

        specialFlags[index] = true;


        // �ۑ��p�̕���

        string storedWord =
            specialWords[index].storedWord;


        // ����R�����g���ɐ���

        AddSpecialWord(storedWord);


        // �O���X�N���v�g�֒ʒm

        OnSpecialWordAppeared?.Invoke(index);


        Debug.Log(
            "����P�� Element "
            + index
            + " ���o�����܂����B"
        );
    }


    // ==================================================
    // ����R�����g�𐶐�
    // ==================================================

    void AddSpecialWord(string word)
    {
        if (specialWordPrefab == null)
        {
            Debug.LogWarning(
                "Special Word Prefab���ݒ肳��Ă��܂���B"
            );

            return;
        }

        if (specialContent == null)
        {
            Debug.LogWarning(
                "Special Content���ݒ肳��Ă��܂���B"
            );

            return;
        }

        if (specialSpawnPoint == null)
        {
            Debug.LogWarning(
                "Special Spawn Point���ݒ肳��Ă��܂���B"
            );

            return;
        }


        // �ő吔�`�F�b�N

        if (specialContent.childCount >= maxSpecialWords)
        {
            return;
        }


        // ==================================================
        // ���ꕶ���𐶐�
        // ==================================================

        GameObject newSpecial =
            Instantiate(
                specialWordPrefab,
                specialContent
            );


        // ==================================================
        // �����ݒ�
        // ==================================================

        TMP_Text text =
            newSpecial.GetComponent<TMP_Text>();


        if (text == null)
        {
            text =
                newSpecial.GetComponentInChildren<TMP_Text>();
        }


        if (text != null)
        {
            text.text = word;
            text.color = specialWordColor;
        }


        // ==================================================
        // �����ʒu��Spawn Point�ɍ��킹��
        // ==================================================

        RectTransform rect =
            newSpecial.GetComponent<RectTransform>();


        if (rect != null)
        {
            rect.position =
                specialSpawnPoint.position;
        }


        // ==================================================
        // ����R�����g����ׂ�
        // ==================================================

        ArrangeSpecialComments();
    }


    // ==================================================
    // �ʏ�R�����g����ׂ�
    // ==================================================

    void ArrangeComments()
    {
        for (int i = 0;
             i < commentContent.childCount;
             i++)
        {
            RectTransform rect =
                commentContent
                    .GetChild(i)
                    .GetComponent<RectTransform>();


            if (rect == null)
                continue;


            rect.position = new Vector3(
                spawnPoint.position.x,

                spawnPoint.position.y
                - (i * commentHeight),

                spawnPoint.position.z
            );
        }
    }


    // ==================================================
    // ����R�����g����ׂ�
    // ==================================================

    void ArrangeSpecialComments()
    {
        for (int i = 0;
             i < specialContent.childCount;
             i++)
        {
            RectTransform rect =
                specialContent
                    .GetChild(i)
                    .GetComponent<RectTransform>();


            if (rect == null)
                continue;


            rect.position = new Vector3(
                specialSpawnPoint.position.x,

                specialSpawnPoint.position.y
                - (i * specialCommentHeight),

                specialSpawnPoint.position.z
            );
        }
    }


    // ==================================================
    // �܂��o�Ă��Ȃ�����P��������_���擾
    // ==================================================

    int GetRandomAvailableSpecialIndex()
    {
        if (specialFlags == null)
            return -1;


        int availableCount = 0;


        for (int i = 0;
             i < specialFlags.Length;
             i++)
        {
            if (!specialFlags[i])
            {
                availableCount++;
            }
        }


        if (availableCount == 0)
        {
            return -1;
        }


        int randomIndex =
            UnityEngine.Random.Range(
                0,
                availableCount
            );


        int count = 0;


        for (int i = 0;
             i < specialFlags.Length;
             i++)
        {
            if (!specialFlags[i])
            {
                if (count == randomIndex)
                {
                    return i;
                }

                count++;
            }
        }


        return -1;
    }


    // ==================================================
    // ����P��̃t���O�擾
    // ==================================================

    public bool GetSpecialFlag(int index)
    {
        if (specialFlags == null)
            return false;

        if (index < 0 ||
            index >= specialFlags.Length)
            return false;

        return specialFlags[index];
    }


    // ==================================================
    // ����P��̃t���O�����Z�b�g
    // ==================================================

    public void ResetSpecialFlag(int index)
    {
        if (specialFlags == null)
            return;

        if (index < 0 ||
            index >= specialFlags.Length)
            return;

        specialFlags[index] = false;
    }
}